# 璃光 Android 项目

## 用 GitHub Actions 编译 APK
1. 在 GitHub 新建仓库 `liuguang-android`。
2. 解压本 ZIP，把里面的所有文件和文件夹上传到仓库根目录。务必包含隐藏目录 `.github/workflows`。
3. 打开仓库的 **Actions** 页面，选择 **Build Liuguang Android APK**。
4. 点击 **Run workflow**，再点击绿色按钮确认。
5. 等待任务成功后，打开本次运行页面底部的 **Artifacts**，下载 `liuguang-debug-apk`。
6. 解压下载的 artifact，得到 `app-debug.apk`，传到 OPPO 手机上安装。

本项目使用 Android WebView 加载本地 assets，不需要网络权限，应用界面资源随 APK 打包。

## 1.0 组件实验室整合更新

本版本在原有首页、学习、我的、离线本地数据功能之外，新增“组件”页，将旧 iApp 程序中的液态玻璃组件移植为 WebView 可运行的 HTML/CSS/JavaScript 控件：玻璃视图、按钮、开关、滑块、三栏标签、弹窗（普通/成功/警告/错误）、下拉选择、进度条、搜索框、顶部/底部提示和悬浮操作按钮。

原始图片资源保存在 `app/src/main/assets/legacy-ui/`，供后续继续复用。原程序依赖的 iApp 专用 Java 控件类没有直接复制进 WebView 工程，而是按原交互重新实现，避免依赖 iApp 运行时。
